import streamlit as st
from keras.models import load_model
from PIL import Image
import numpy as np
import tensorflow as tf
from keras.preprocessing import image

from util import classify, set_background


set_background('./OIP5.jpeg')

# set title
st.title('Breast Cancer classification')

# set header
st.header('Please upload a histopathological image')

# upload file
file = st.file_uploader('', type=['jpeg', 'jpg', 'png'])

# load classifier
model = load_model('./breast_canser22.h5')


# display image
if file is not None:
    image = Image.open(file).convert('RGB')
    st.image(image, use_column_width=True)



    test_image = tf.keras.utils.load_img(file,target_size=(224,224))  
    test_image = tf.keras.utils.img_to_array(test_image)
    test_image = np.expand_dims(test_image, axis = 0)

    #predict the result
    result = model.predict(test_image)
    if result[0] < .5:
        s = f"<p style='font-size:50px;color:black;'>Bening</p>"
        st.markdown(s, unsafe_allow_html=True)  
        #st.markdown("Bening")
    else:
        s = f"<p style='font-size:50px; color:black;'>malignant</p>"
        st.markdown(s, unsafe_allow_html=True)  
        #st.markdown("malignant")

   